package com.jovis.t20.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/*
 * Paleta da ficha:
 *  - primary: tinta azul-escura, para texto de destaque e títulos
 *  - tertiary: vermelho da Tormenta, reservado para Pontos de Vida
 *  - secondary: azul arcano, reservado para Pontos de Mana
 */

private val T20Light = lightColorScheme(
    primary = Color(0xFF243256),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCE2F2),
    onPrimaryContainer = Color(0xFF111A33),
    secondary = Color(0xFF2D6AA8),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDDE8F5),
    onSecondaryContainer = Color(0xFF0E2A47),
    tertiary = Color(0xFFB02A3C),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF7DEE1),
    onTertiaryContainer = Color(0xFF4A0D17),
    background = Color(0xFFF3F5F8),
    onBackground = Color(0xFF1A1F2B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1F2B),
    surfaceVariant = Color(0xFFE4E8EF),
    onSurfaceVariant = Color(0xFF4A5366),
    outline = Color(0xFF8A93A6),
    outlineVariant = Color(0xFFCDD3DE),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8F9FB),
    surfaceContainer = Color(0xFFF1F3F7),
    surfaceContainerHigh = Color(0xFFEBEEF3),
    surfaceContainerHighest = Color(0xFFE4E8EF),
)

private val T20Dark = darkColorScheme(
    primary = Color(0xFFB7C4E8),
    onPrimary = Color(0xFF14203C),
    primaryContainer = Color(0xFF2E3B5F),
    onPrimaryContainer = Color(0xFFDCE2F2),
    secondary = Color(0xFF8FB8E6),
    onSecondary = Color(0xFF0E2A47),
    secondaryContainer = Color(0xFF213B57),
    onSecondaryContainer = Color(0xFFDDE8F5),
    tertiary = Color(0xFFF08A97),
    onTertiary = Color(0xFF4A0D17),
    tertiaryContainer = Color(0xFF5A1F28),
    onTertiaryContainer = Color(0xFFF7DEE1),
    background = Color(0xFF14171D),
    onBackground = Color(0xFFE4E7EE),
    surface = Color(0xFF1B1F27),
    onSurface = Color(0xFFE4E7EE),
    surfaceVariant = Color(0xFF2A303B),
    onSurfaceVariant = Color(0xFFB4BBC9),
    outline = Color(0xFF6B7385),
    outlineVariant = Color(0xFF3A414E),
    surfaceContainerLowest = Color(0xFF101318),
    surfaceContainerLow = Color(0xFF181B22),
    surfaceContainer = Color(0xFF1E222A),
    surfaceContainerHigh = Color(0xFF252A33),
    surfaceContainerHighest = Color(0xFF2E343F),
)

@Composable
fun T20Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) T20Dark else T20Light,
        content = content,
    )
}

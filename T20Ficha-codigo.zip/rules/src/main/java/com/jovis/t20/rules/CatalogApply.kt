package com.jovis.t20.rules

/**
 * Aplica escolhas do catálogo a uma ficha, sem apagar o que o jogador já preencheu.
 * Itens já presentes (mesmo nome) não são duplicados.
 */
object CatalogApply {

    fun applyClass(sheet: ManualSheet, cls: CatalogClass): ManualSheet {
        // Ao trocar de classe, o caminho anterior deixa de valer
        val pathId = sheet.classPathId.takeIf { sheet.classId == cls.id && cls.pathById(it) != null }
        val casting = cls.castingFor(pathId)
        return sheet.copy(
            classId = cls.id,
            classPathId = pathId,
            className = cls.name,
            hpFirstLevel = cls.hpFirstLevel,
            hpPerLevel = cls.hpPerLevel,
            mpPerLevel = cls.mpPerLevel,
            mpAttribute = cls.mpAttribute ?: casting?.attribute,
            spellAttribute = casting?.attribute,
            trainedSkills = sheet.trainedSkills + cls.fixedSkills,
        )
    }

    /** Escolhe o caminho da classe (ex.: arcanista mago), que define o atributo das magias e dos PM. */
    fun applyPath(sheet: ManualSheet, path: ClassPath): ManualSheet = sheet.copy(
        classPathId = path.id,
        mpAttribute = path.spellcasting.attribute,
        spellAttribute = path.spellcasting.attribute,
    )

    /** As regras de magia que valem para a ficha (classe e caminho), ou null se não for conjurador. */
    fun casting(sheet: ManualSheet): Spellcasting? = ClassCatalog.byId(sheet.classId)?.castingFor(sheet.classPathId)

    fun applyRace(sheet: ManualSheet, race: CatalogRace): ManualSheet = sheet.copy(
        raceId = race.id,
        race = race.name,
        baseSpeed = race.speed,
        abilities = mergeEntries(sheet.abilities, race.abilities),
        skillBonuses = race.skillBonuses.entries.fold(sheet.skillBonuses) { acc, (skill, bonuses) ->
            acc + (skill to mergeBonuses(acc[skill].orEmpty(), bonuses))
        },
        mpBonuses = mergeBonuses(sheet.mpBonuses, race.mpBonuses),
        defenseBonuses = mergeBonuses(sheet.defenseBonuses, race.defenseBonuses),
    )

    fun applyOrigin(sheet: ManualSheet, origin: CatalogOrigin): ManualSheet =
        sheet.copy(originId = origin.id, origin = origin.name)

    /** Magias que o personagem pode escolher agora, pelas regras da classe. Vazio se não for conjurador. */
    fun availableSpells(sheet: ManualSheet): List<CatalogSpell> {
        val casting = casting(sheet) ?: return emptyList()
        return SpellCatalog.available(casting, sheet.spellSchools, sheet.level)
    }

    /** Quantas magias de classe o personagem conhece no nível atual, ou null se não for conjurador. */
    fun classSpellsKnown(sheet: ManualSheet): Int? =
        casting(sheet)?.spellsKnown(sheet.level)

    private fun mergeEntries(current: List<SheetEntry>, new: List<SheetEntry>) =
        current + new.filter { n -> current.none { it.name.equals(n.name, ignoreCase = true) } }

    private fun mergeBonuses(current: List<SheetBonus>, new: List<SheetBonus>) =
        current + new.filter { n -> current.none { it.label.equals(n.label, ignoreCase = true) } }
}
